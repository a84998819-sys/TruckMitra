TruckMitra website package

Open index.html in a modern browser or upload it to your web hosting.
truckmitra-logo.png is the generated logo asset.
The route planner uses OpenStreetMap/Nominatim and OSRM services, so an internet connection is required.
Voice search depends on browser speech-recognition support and microphone permission.
